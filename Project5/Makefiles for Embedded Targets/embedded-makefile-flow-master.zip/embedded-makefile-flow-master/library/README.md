This folder contains pre-compiled libraries that the project will link against.
