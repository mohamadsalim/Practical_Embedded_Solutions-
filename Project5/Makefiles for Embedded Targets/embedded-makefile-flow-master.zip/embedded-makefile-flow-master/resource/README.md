This folder holds resources with information related to this project.

# stm32f0xxx_cortex_m0_programming.pdf

Contains information relating to the instruction set and program behavior.

# stm32f0xxx_cortex_m0_device.pdf

Contains information relating to device peripherals and configuration.
