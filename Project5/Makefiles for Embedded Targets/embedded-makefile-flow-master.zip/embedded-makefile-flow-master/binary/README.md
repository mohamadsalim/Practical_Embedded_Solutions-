This folder contains compiled executables, intermediate objects, and libraries.
