This folder contains architecture/device specific files

There is a rats nest of header includes, that was just copy pasted from the STM32Cube.
