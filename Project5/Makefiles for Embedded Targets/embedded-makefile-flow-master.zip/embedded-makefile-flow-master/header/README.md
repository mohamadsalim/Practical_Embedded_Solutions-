This folder containes non-architecture specific header files used by this project.
