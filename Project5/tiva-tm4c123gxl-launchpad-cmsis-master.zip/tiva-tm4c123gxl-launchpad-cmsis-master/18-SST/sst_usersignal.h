#ifndef _SST_USERSIGNAL_H_
#define _SST_USERSIGNAL_H_
/**
 * @file     sst_usersignal.h
 * @brief    Super Simple Tasker
 * @version  V1.0
 * @date     23/01/2016
 *
 * @note     Created for this project
 *
 ******************************************************************************/

#define ISR_JOY_SIG_BASE     200
#define ISR_TICK_SIG         40

#endif
